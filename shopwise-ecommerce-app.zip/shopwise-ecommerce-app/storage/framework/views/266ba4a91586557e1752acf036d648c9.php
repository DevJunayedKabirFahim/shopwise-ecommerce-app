<?php $__env->startSection('title', 'Add Category'); ?>
<?php $__env->startSection('body'); ?>
    <!-- PAGE-HEADER -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Subcategory Module</h1>
        </div>
        <div class="ms-auto pageheader-btn">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0);">Subcategory</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add Subcategory</li>
            </ol>
        </div>
    </div>
    <!-- PAGE-HEADER END -->

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h3 class="card-title">Add Subcategory Form</h3>
                </div>
                <div class="card-body">
                    <p class="text-success"><?php echo e(session('message')); ?></p>
                    <form class="form-horizontal" method="post" action="<?php echo e(route('sub-category.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Select Category</label>
                            <div class="col-md-9">
                                <select name="category_id" class="form-control" required>
                                    <option disabled selected> --- Select any category --- </option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-white bg-danger"><?php echo e($errors->has('category_id') ? $errors->first('category_id') : ''); ?></span>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="name" class="col-md-3 form-label">Subcategory Name</label>
                            <div class="col-md-9">
                                <input class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" placeholder="Enter Subcategory Name" type="text">
                                <span class="text-white bg-danger"><?php echo e($errors->has('name') ? $errors->first('name') : ''); ?></span>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="description" class="col-md-3 form-label">Description</label>
                            <div class="col-md-9">
                                <textarea class="form-control" maxlength="225"  name="description" id="description" placeholder="Enter subcategory description" rows="3"><?php echo e(old('description')); ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="image" class="col-md-3 form-label">Image</label>
                            <div class="col-sm-12 col-md-5 mg-t-10 mg-sm-t-0">
                                <input type="file" name="image" class="dropify" data-height="200" />
                            </div>
                        </div>

                        <div class="row">
                            <label class="col-md-3 form-label">Status</label>
                            <div class="col-md-3 pt-3">
                                <label><input name="status" checked type="radio" value="1"> <span>Published</span></label>
                                <label><input name="status" type="radio" value="0"> <span>Unpublished</span></label>
                            </div>
                            <div class="col-md-3 pt-3">
                                <span class="text-white bg-danger"><?php echo e($errors->has('status') ? $errors->first('status') : ''); ?></span>
                            </div>
                        </div>
                        
                        <button class="btn btn-primary float-end" type="submit">Create new subcategory</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopwise-ecommerce-app\resources\views/admin/sub-category/add.blade.php ENDPATH**/ ?>
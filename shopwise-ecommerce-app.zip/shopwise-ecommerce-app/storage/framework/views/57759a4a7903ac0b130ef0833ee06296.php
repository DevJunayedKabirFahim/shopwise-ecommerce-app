<!-- FAVICON -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/')); ?>website/assets/images/favicon.png">

<!-- BOOTSTRAP CSS -->
<link id="style" href="<?php echo e(asset('/')); ?>admin/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

<!-- STYLE CSS -->
<link href="<?php echo e(asset('/')); ?>admin/assets/css/style.css" rel="stylesheet" />
<link href="<?php echo e(asset('/')); ?>admin/assets/css/skin-modes.css" rel="stylesheet" />



<!--- FONT-ICONS CSS -->
<link href="<?php echo e(asset('/')); ?>admin/assets/plugins/icons/icons.css" rel="stylesheet" />

<!-- INTERNAL Switcher css -->
<link href="<?php echo e(asset('/')); ?>admin/assets/switcher/css/switcher.css" rel="stylesheet"/>
<link href="<?php echo e(asset('/')); ?>admin/assets/switcher/demo.css" rel="stylesheet"/>
<?php /**PATH C:\xampp\htdocs\shopwise-ecommerce-app\resources\views/admin/includes/style.blade.php ENDPATH**/ ?>
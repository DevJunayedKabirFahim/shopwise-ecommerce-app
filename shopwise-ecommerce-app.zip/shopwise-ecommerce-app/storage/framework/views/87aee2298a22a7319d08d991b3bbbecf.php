<?php $__env->startSection('title', 'Edit Product Info'); ?>
<?php $__env->startSection('body'); ?>
    <!-- PAGE-HEADER -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Product Module</h1>
        </div>
        <div class="ms-auto pageheader-btn">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0);">Product</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit Product</li>
            </ol>
        </div>
    </div>
    <!-- PAGE-HEADER END -->

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-header border-bottom">
                    <h3 class="card-title">Edit Product Form</h3>
                </div>
                <div class="card-body">
                    <p class="text-success"><?php echo e(session('message')); ?></p>
                    <form class="form-horizontal" method="post" action="<?php echo e(route('product.update', $product->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Select Category</label>
                            <div class="col-md-9 form-group">
                                <select name="category_id" onchange="setSubCategory(this.value)" class="form-control select2-show-search form-select w-100" data-placeholder="Choose any category">
                                    <option label="Choose one"></option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php if($category->id == $product->category_id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Select SubCategory</label>
                            <div class="col-md-9 form-group">
                                <select name="sub_category_id" id="subCategoryId" class="form-control select2 form-select w-100" data-placeholder="Choose any subcategory">
                                    <option label="Choose one"></option>
                                    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subCategory->id); ?>" <?php if($subCategory->id == $product->sub_category_id): echo 'selected'; endif; ?>><?php echo e($subCategory->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-white bg-danger"><?php echo e($errors->has('sub_category_id') ? $errors->first('sub_category_id') : ''); ?></span>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Select Brand</label>
                            <div class="col-md-9 form-group">
                                <select name="brand_id" class="form-control select2-show-search form-select w-100" data-placeholder="Choose any brand">
                                    <option label="Choose one"></option>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand->id); ?>" <?php if($brand->id == $product->brand_id): echo 'selected'; endif; ?>><?php echo e($brand->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-white bg-danger"><?php echo e($errors->has('brand_id') ? $errors->first('brand_id') : ''); ?></span>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Select Unit</label>
                            <div class="col-md-9 form-group">
                                <select name="unit_id" class="form-control select2-show-search form-select w-100" data-placeholder="Choose any unit">
                                    <option label="Choose one"></option>
                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($unit->id); ?>" <?php if($unit->id == $product->unit_id): echo 'selected'; endif; ?>><?php echo e($unit->code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-white bg-danger"><?php echo e($errors->has('unit_id') ? $errors->first('unit_id') : ''); ?></span>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Select Colors</label>
                            <div class="col-md-9 form-group">
                                <select multiple class="form-control select2-show-search form-select" name="colors[]" data-placeholder="Choose colors">
                                    <option label="Choose one"></option>
                                    <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($color->id); ?>" <?php $__currentLoopData = $product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleColor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($color->id == $singleColor->color_id): echo 'selected'; endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($color->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <span class="text-white bg-danger"><?php echo e($errors->has('color_id') ? $errors->first('color_id') : ''); ?></span>
                        </div>
                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Select Size</label>
                            <div class="col-md-9 form-group">
                                <select multiple class="form-control select2-show-search form-select" name="sizes[]" data-placeholder="Choose sizes">
                                    <option label="Choose one"></option>
                                    <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($size->id); ?>" <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleSize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($size->id == $singleSize->size_id): echo 'selected'; endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>><?php echo e($size->code); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="name" class="col-md-3 form-label">Product Name</label>
                            <div class="col-md-9">
                                <input class="form-control" id="name" name="name" value="<?php echo e($product->name); ?>" placeholder="Enter product Name" type="text">
                                <span class="text-white bg-danger"><?php echo e($errors->has('name') ? $errors->first('name') : ''); ?></span>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="code" class="col-md-3 form-label">Product Code</label>
                            <div class="col-md-9">
                                <input class="form-control" id="code" name="code" value="<?php echo e($product->code); ?>" placeholder="Enter product code" type="text">
                                <span class="text-white bg-danger"><?php echo e($errors->has('code') ? $errors->first('code') : ''); ?></span>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="short_description" class="col-md-3 form-label">Short Description</label>
                            <div class="col-md-9">
                                <textarea class="form-control" maxlength="225"  name="short_description" id="short_description" placeholder="Enter product short description" rows="2"><?php echo e($product->short_description); ?></textarea>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="long_description" class="col-md-3 form-label">Long Description</label>
                            <div class="col-md-9">
                                <div class="card card-body">
                                    <textarea class="content" name="long_description"><?php echo e($product->long_description); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="image" class="col-md-3 form-label">Image</label>
                            <div class="col-sm-12 col-md-5 mg-t-10 mg-sm-t-0">
                                <input type="file" name="image" class="dropify" data-height="200" />
                                <img src="<?php echo e(asset($product->image)); ?>" alt="" height="120" width="130"/>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label for="image" class="col-md-3 form-label">Sub Images</label>
                            <div class="col-sm-12 col-md-5 mg-t-10 mg-sm-t-0">
                                <input type="file" name="sub_Images[]" class="form-control"  multiple/>
                                <?php $__currentLoopData = $product->productSubImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productSubImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset($productSubImage->image)); ?>" alt="" height="120" width="130"/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="row mb-4">
                            <label class="col-md-3 form-label">Product Price</label>
                            <div class="col-sm-12 col-md-9 mg-t-10 mg-sm-t-0">
                                <div class="input-group">
                                    <input type="number" class="form-control" value="<?php echo e($product->regular_price); ?>" name="regular_price" placeholder="Enter regular price"/>
                                    <input type="number" class="form-control" value="<?php echo e($product->selling_price); ?>" name="selling_price" placeholder="Enter discounted price"/>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-4">
                            <label id="stock_amount" class="col-md-3 form-label">Stock Amount</label>
                            <div class="col-sm-12 col-md-9 mg-t-10 mg-sm-t-0">
                                <input id="stock_amount" type="number" class="form-control" value="<?php echo e($product->stock_amount); ?>" name="stock_amount" placeholder="Enter stock amount"/>
                            </div>
                        </div>

                        <div class="row">
                            <label class="col-md-3 form-label">Status</label>
                            <div class="col-md-3 pt-3">
                                <label><input name="status" checked type="radio" <?php echo e($product->status == 1 ? 'checked' : ''); ?> value="1"> <span>Published</span></label>
                                <label><input name="status" type="radio" <?php echo e($product->status == 0 ? 'checked' : ''); ?> value="0"> <span>Unpublished</span></label>
                            </div>
                            <div class="col-md-3 pt-3">
                                <span class="text-white bg-danger"><?php echo e($errors->has('status') ? $errors->first('status') : ''); ?></span>
                            </div>
                        </div>
                        
                        <button class="btn btn-primary float-end" type="submit">Update Product info</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopwise-ecommerce-app\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>
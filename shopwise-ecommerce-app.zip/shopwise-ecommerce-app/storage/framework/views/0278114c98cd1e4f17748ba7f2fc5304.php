<?php $__env->startSection('title', 'Order Detail'); ?>

<?php $__env->startSection('body'); ?>
    <style>
        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 30px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
            font-size: 16px;
            line-height: 24px;
            font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
            color: #555;
        }

        .invoice-box table {
            width: 100%;
            line-height: inherit;
            text-align: left;
        }

        .invoice-box table td {
            padding: 5px;
            vertical-align: top;
        }

        .invoice-box table tr td:nth-child(2) {
            text-align: right;
        }

        .invoice-box table tr.top table td {
            padding-bottom: 20px;
        }

        .invoice-box table tr.top table td.title {
            font-size: 45px;
            line-height: 45px;
            color: #333;
        }

        .invoice-box table tr.information table td {
            padding-bottom: 40px;
        }

        .invoice-box table tr.heading td {
            background: #eee;
            border-bottom: 1px solid #ddd;
            font-weight: bold;
        }

        .invoice-box table tr.details td {
            padding-bottom: 20px;
        }

        .invoice-box table tr.item td {
            border-bottom: 1px solid #eee;
        }

        .invoice-box table tr.item.last td {
            border-bottom: none;
        }

        .invoice-box table tr.total td:nth-child(2) {
            border-top: 2px solid #eee;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            .invoice-box table tr.top table td {
                width: 100%;
                display: block;
                text-align: center;
            }

            .invoice-box table tr.information table td {
                width: 100%;
                display: block;
                text-align: center;
            }
        }

        /** RTL **/
        .invoice-box.rtl {
            direction: rtl;
            font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        }

        .invoice-box.rtl table {
            text-align: right;
        }

        .invoice-box.rtl table tr td:nth-child(2) {
            text-align: left;
        }
    </style>

    <!-- PAGE-HEADER -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Order Module</h1>
        </div>
        <div class="ms-auto pageheader-btn">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0);">Order</a></li>
                <li class="breadcrumb-item active" aria-current="page">Order Invoice</li>
            </ol>
        </div>
    </div>
    <!-- PAGE-HEADER END -->

    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-header border-bottom">
                    <h3 class="card-title">Order Detail Content</h3>
                </div>
                <div class="card-body">
                    <div class="invoice-box">
                        <table cellpadding="0" cellspacing="0">
                            <tr class="top">
                                <td colspan="4">
                                    <table>
                                        <tr>
                                            <td class="title">
                                                <img
                                                    src="<?php echo e(asset('/')); ?>website/assets/images/logo_dark.png"
                                                    style="width: 100%; max-width: 300px"
                                                />
                                            </td>

                                            <td>
                                                Invoice #: 00<?php echo e($order->id); ?><br />
                                                Order Date: <?php echo e($order->order_date); ?><br />
                                                Invoice Date: <?php echo e(date('Y-m-d')); ?>

                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr class="information">
                                <td colspan="4">
                                    <table>
                                        <tr>
                                            <td >
                                                <h4>Delivery Address</h4>
                                                <?php echo e($order->customer->name); ?><br />
                                                <?php echo e($order->customer->email); ?><br />
                                                <?php echo e($order->customer->mobile); ?><br/>
                                                <?php echo e($order->delivery_address); ?><br/>
                                            </td>

                                            <td>
                                                <h4>Company Info</h4>
                                                Shopwise E-commerce Limited<br />
                                                shopwise.online@ecommerce.com<br/>
                                                (+880) 1701-057048<br />
                                                BITM, Kawran Bazar, 1200<br />
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr class="heading">
                                <td colspan="3">Payment Method</td>
                                <td><?php echo e($order->payment_method); ?></td>
                            </tr>

                            <tr class="details">
                                <td colspan="3"><?php echo e($order->payment_method); ?></td>

                                <td>$<?php echo e($order->order_total); ?></td>
                            </tr>

                            <tr class="heading">
                                <td colspan="3">Item</td>

                                <td>Price</td>
                            </tr>

                            <tr class="item">
                                <td>Item Info</td>
                                <td align="center">Unit Price</td>
                                <td align="center">Quantity</td>
                                <td align="right">Sub Total</td>
                            </tr>
                            <?php ($sum = 0); ?>
                            <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item">
                                <td><?php echo e($orderDetail->product_name); ?></td>
                                <td align="center">$<?php echo e($orderDetail->product_price); ?></td>
                                <td align="center"><?php echo e($orderDetail->product_qty); ?></td>
                                <td align="right">$<?php echo e($total = $orderDetail->product_price * $orderDetail->product_qty); ?></td>
                            </tr>
                                <?php ($sum = $sum + $total); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td align="right">Sub Total: $<?php echo e($sum); ?></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td align="right">Tax: $<?php echo e(round($tax = $sum*0.15)); ?></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td align="right">Shipping Cost: $<?php echo e($shipping = 100); ?></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td align="right">Total Payable: $<?php echo e(round($sum + $tax + $shipping)); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopwise-ecommerce-app\resources\views/admin/order/invoice-show.blade.php ENDPATH**/ ?>